# lowOpacity

**This add-on injects JavaScript into web pages. The `addons.mozilla.org` domain disallows this operation, so this add-on will not work properly when it's run on pages in the `addons.mozilla.org` domain.**

# What it does

The add-on reduces the opacity of the web pages from Mozilla Firefox domain.