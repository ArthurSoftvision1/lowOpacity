// Sets the body opacity

document.body.style = "opacity: 0.5";

